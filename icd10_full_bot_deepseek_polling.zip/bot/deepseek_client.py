import httpx
import json
from .settings import settings

DEEPSEEK_API_URL = "https://api.deepseek.com/chat/completions"  # при необходимости поменяй

SYSTEM_PROMPT = (
    "Ты медицинский ассистент-кодировщик. "
    "По клиническому описанию верни JSON с массивом объектов {code, confidence} для МКБ-10. "
    "Не добавляй пояснения, только JSON."
)

USER_PROMPT_TEMPLATE = (
    "Текст: {text}\n"
    "Важно: верни строго JSON вида {{"codes":[{{"code":"A00.0","confidence":0.92}}, ...]}}. "
    "Коды — только формата МКБ-10 (буква+цифры, точки допустимы)."
)

async def suggest_icd10(text: str):
    headers = {
        "Authorization": f"Bearer {settings.deepseek_api_key}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": USER_PROMPT_TEMPLATE.format(text=text)}
        ],
        "temperature": 0.2,
        "response_format": {"type": "json_object"}
    }
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(DEEPSEEK_API_URL, headers=headers, json=payload)
        r.raise_for_status()
        data = r.json()
        content = data["choices"][0]["message"]["content"]
        try:
            parsed = json.loads(content)
        except json.JSONDecodeError:
            parsed = {"codes": []}
        codes = parsed.get("codes", [])
        # нормализуем
        norm = []
        for item in codes:
            code = str(item.get("code","")).strip()
            try:
                conf = float(item.get("confidence", 0.0))
            except:
                conf = 0.0
            if code:
                norm.append({"code": code, "confidence": conf})
        return norm
