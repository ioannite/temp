import pandas as pd
from .settings import settings
from .db import codes_exist, bulk_insert_codes

async def ensure_icd10_loaded():
    if await codes_exist():
        return
    # CSV формат: code,title_ru
    df = pd.read_csv(settings.icd10_csv_path, header=None, names=["code","title_ru"], dtype=str)
    # Уберём пробелы/кавычки
    df["code"] = df["code"].str.strip()
    df["title_ru"] = df["title_ru"].str.replace('^"|"$', '', regex=True).str.strip()
    rows = list(df.itertuples(index=False, name=None))
    await bulk_insert_codes(rows)
