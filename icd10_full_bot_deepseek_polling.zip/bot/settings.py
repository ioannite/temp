from pydantic import BaseModel
import os

class Settings(BaseModel):
    bot_token: str = os.getenv("BOT_TOKEN", "")
    deepseek_api_key: str = os.getenv("DEEPSEEK_API_KEY", "")
    confidence_threshold: float = float(os.getenv("CONFIDENCE_THRESHOLD", "0.75"))
    icd10_csv_path: str = os.getenv("ICD10_CSV_PATH", "/data/icd10.csv")
    db_host: str = os.getenv("DB_HOST", "db")
    db_port: int = int(os.getenv("DB_PORT", "5432"))
    db_user: str = os.getenv("DB_USER", "bot")
    db_password: str = os.getenv("DB_PASSWORD", "botpass")
    db_name: str = os.getenv("DB_NAME", "icd10")

settings = Settings()
