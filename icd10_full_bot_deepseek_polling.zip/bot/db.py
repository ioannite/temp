import asyncpg
from .settings import settings

_pool = None

CREATE_SQL = """
CREATE EXTENSION IF NOT EXISTS pg_trgm;

CREATE TABLE IF NOT EXISTS codes (
    code TEXT PRIMARY KEY,
    title_ru TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS queries (
    id SERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    text TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS suggestions (
    id SERIAL PRIMARY KEY,
    query_id INT REFERENCES queries(id) ON DELETE CASCADE,
    code TEXT,
    score REAL,
    source TEXT, -- 'llm' | 'search'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""

async def pool():
    global _pool
    if _pool is None:
        _pool = await asyncpg.create_pool(
            host=settings.db_host,
            port=settings.db_port,
            user=settings.db_user,
            password=settings.db_password,
            database=settings.db_name,
            min_size=1,
            max_size=10
        )
    return _pool

async def init_db():
    p = await pool()
    async with p.acquire() as conn:
        await conn.execute(CREATE_SQL)

async def codes_exist() -> bool:
    p = await pool()
    async with p.acquire() as conn:
        row = await conn.fetchrow("SELECT COUNT(*) AS c FROM codes")
        return row["c"] > 0

async def bulk_insert_codes(rows):
    p = await pool()
    async with p.acquire() as conn:
        async with conn.transaction():
            await conn.executemany(
                "INSERT INTO codes (code, title_ru) VALUES ($1, $2) ON CONFLICT (code) DO UPDATE SET title_ru=EXCLUDED.title_ru",
                rows
            )

async def save_query(user_id: int, text: str) -> int:
    p = await pool()
    async with p.acquire() as conn:
        row = await conn.fetchrow("INSERT INTO queries (user_id, text) VALUES ($1,$2) RETURNING id", user_id, text)
        return row["id"]

async def add_suggestion(query_id: int, code: str, score: float, source: str):
    p = await pool()
    async with p.acquire() as conn:
        await conn.execute(
            "INSERT INTO suggestions (query_id, code, score, source) VALUES ($1,$2,$3,$4)",
            query_id, code, score, source
        )

async def get_code_title(code: str):
    p = await pool()
    async with p.acquire() as conn:
        row = await conn.fetchrow("SELECT title_ru FROM codes WHERE code=$1", code)
        return row["title_ru"] if row else None

async def search_codes_by_text(q: str, limit: int = 10):
    p = await pool()
    async with p.acquire() as conn:
        # Комбинация ILIKE + trigram similarity если есть
        rows = await conn.fetch(
            """
            SELECT code, title_ru,
                   GREATEST(similarity(title_ru, $1), similarity(code, $1)) AS sim
            FROM codes
            WHERE title_ru ILIKE '%' || $1 || '%' OR code ILIKE '%' || $1 || '%'
            ORDER BY sim DESC
            LIMIT $2
            """,
            q, limit
        )
        return [(r["code"], r["title_ru"], float(r["sim"])) for r in rows]
