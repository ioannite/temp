import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.filters import Command
from aiogram.types import Message
from .settings import settings
from .db import init_db
from .icd_loader import ensure_icd10_loaded
from .logic import handle_query

logging.basicConfig(level=logging.INFO)

bot = Bot(token=settings.bot_token)
dp = Dispatcher()

@dp.message(Command("start"))
async def start_cmd(m: Message):
    await m.answer("Привет! Отправь диагноз/симптомы — подберу коды МКБ-10.
/help — подсказка")

@dp.message(Command("help"))
async def help_cmd(m: Message):
    await m.answer("Напиши описание клинического случая или диагноз на русском языке — я предложу релевантные коды МКБ-10.\nПорог доверия настраивается: CONFIDENCE_THRESHOLD.")

@dp.message()
async def on_text(m: Message):
    reliable, suggestions = await handle_query(m.from_user.id, m.text)

    def fmt(rows):
        if not rows: return "—"
        return "\n".join([f"{r['code']} — {r.get('title') or 'нет в справочнике'} (score: {r['score']})" for r in rows])

    msg = f"Надёжные (≥ {settings.confidence_threshold}):\n{fmt(reliable)}\n\nПредложения:\n{fmt(suggestions)}"
    await m.answer(msg)

async def main():
    if not settings.bot_token:
        raise RuntimeError("BOT_TOKEN пуст. Укажи его в .env")
    await init_db()
    await ensure_icd10_loaded()
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
