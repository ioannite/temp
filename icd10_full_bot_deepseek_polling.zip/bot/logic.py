from .db import save_query, add_suggestion, get_code_title, search_codes_by_text
from .deepseek_client import suggest_icd10
from .settings import settings

async def handle_query(user_id: int, text: str):
    query_id = await save_query(user_id, text)

    # 1) LLM предлагает коды
    llm_codes = await suggest_icd10(text)

    results_map = {}

    # 2) Сохраняем LLM-предложения и подтягиваем названия кодов из БД
    for item in llm_codes:
        code = item["code"]
        conf = float(item.get("confidence", 0.0))
        title = await get_code_title(code)
        results_map[code] = {
            "code": code,
            "title": title,  # может быть None, если нет в справочнике
            "score_llm": conf,
            "score_search": 0.0
        }
        await add_suggestion(query_id, code, conf, "llm")

    # 3) Поиск по тексту в БД (fuzzy)
    search_hits = await search_codes_by_text(text, limit=10)
    for code, title, sim in search_hits:
        if code not in results_map:
            results_map[code] = {"code": code, "title": title, "score_llm": 0.0, "score_search": float(sim)}
        else:
            results_map[code]["title"] = results_map[code]["title"] or title
            results_map[code]["score_search"] = max(results_map[code]["score_search"], float(sim))
        await add_suggestion(query_id, code, float(sim), "search")

    # 4) Агрегация: берём максимум из источников
    aggregated = []
    for code, obj in results_map.items():
        final_score = max(obj["score_llm"], obj["score_search"])
        aggregated.append({
            "code": code,
            "title": obj["title"],
            "score": round(final_score, 3),
            "present_in_db": obj["title"] is not None
        })

    # 5) Разделяем по порогу
    thr = settings.confidence_threshold
    reliable = [r for r in aggregated if r["score"] >= thr and r["present_in_db"]]
    suggestions = [r for r in aggregated if r not in reliable]

    # Сортировка
    reliable.sort(key=lambda x: x["score"], reverse=True)
    suggestions.sort(key=lambda x: x["score"], reverse=True)

    return reliable[:10], suggestions[:10]
