# ICD-10 Telegram Bot (Polling) with DeepSeek + PostgreSQL

Функции:
- Поллинг (без вебхуков)
- PostgreSQL для хранения справочника и истории запросов
- Автозагрузка МКБ-10 из CSV (формат: `A00,Холера` ...)
- Интеграция с DeepSeek (chat completions) для рекомендаций кодов
- Порог доверия `CONFIDENCE_THRESHOLD` (>= показывает в «Надёжных», ниже — в «Предложениях»)

## Быстрый старт

1) Отредактируй `.env`:
```
BOT_TOKEN=ваш_токен_бота
DEEPSEEK_API_KEY=ваш_api_key
CONFIDENCE_THRESHOLD=0.75
ICD10_CSV_PATH=/data/icd10.csv   # положи файл рядом и подключи volume
DB_HOST=db
DB_PORT=5432
DB_USER=bot
DB_PASSWORD=botpass
DB_NAME=icd10
```

2) Положи свой `icd10.csv` рядом с `docker-compose.yml` или поправь путь.

3) Запуск:
```bash
docker compose up -d --build
docker logs -f icd10_bot
```

4) Напиши боту любой диагноз или симптомы на русском — бот вернёт коды МКБ-10.
