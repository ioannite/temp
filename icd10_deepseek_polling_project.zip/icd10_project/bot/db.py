import os
import asyncpg
from loguru import logger

DB_HOST = os.getenv("DB_HOST", "db")
DB_PORT = int(os.getenv("DB_PORT", "5432"))
DB_NAME = os.getenv("POSTGRES_DB", "icd10")
DB_USER = os.getenv("POSTGRES_USER", "icduser")
DB_PASS = os.getenv("POSTGRES_PASSWORD", "icdpass")

_pool: asyncpg.Pool | None = None

async def get_pool() -> asyncpg.Pool:
    global _pool
    if _pool is None:
        logger.info("Connecting to PostgreSQL...")
        _pool = await asyncpg.create_pool(
            host=DB_HOST, port=DB_PORT,
            user=DB_USER, password=DB_PASS, database=DB_NAME,
            min_size=1, max_size=5
        )
    return _pool

async def exec(script: str, *args):
    pool = await get_pool()
    async with pool.acquire() as con:
        return await con.execute(script, *args)

async def fetch(query: str, *args):
    pool = await get_pool()
    async with pool.acquire() as con:
        return await con.fetch(query, *args)

async def fetchrow(query: str, *args):
    pool = await get_pool()
    async with pool.acquire() as con:
        return await con.fetchrow(query, *args)
