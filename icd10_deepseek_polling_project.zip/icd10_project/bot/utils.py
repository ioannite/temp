import re

CODE_RE = re.compile(r'^[A-TV-Z][0-9]{2}(?:\.[A-Z0-9]{1,4})?$', re.IGNORECASE)

def normalize_code(code: str) -> str:
    code = (code or "").strip().upper()
    code = code.replace(",", ".")
    return code

def looks_like_code(token: str) -> bool:
    return bool(CODE_RE.match(normalize_code(token)))
