import os, csv, io
from loguru import logger
from . import db

CSV_PATH = os.getenv("ICD10_CSV_PATH", "/data/icd10.csv")

async def ensure_codes_loaded():
    row = await db.fetchrow("SELECT COUNT(*) AS c FROM codes")
    if row and row["c"] > 0:
        logger.info("Codes already present in DB, skip CSV load")
        return

    if not os.path.exists(CSV_PATH):
        logger.error(f"CSV not found at {CSV_PATH}")
        return

    logger.info(f"Loading ICD-10 from {CSV_PATH} ...")
    added = 0
    with open(CSV_PATH, "rb") as f:
        raw = f.read()
    for enc in ("utf-8-sig", "cp1251"):
        try:
            text = raw.decode(enc)
            break
        except Exception:
            text = None
    if text is None:
        raise RuntimeError("Unable to decode CSV as utf-8 or cp1251")

    reader = csv.reader(io.StringIO(text))
    batch = []
    for row in reader:
        if not row: 
            continue
        code = (row[0] or "").strip()
        title = (row[1] if len(row) > 1 else "").strip()
        if not code or not title:
            continue
        batch.append((code, title))

    if batch:
        values = ",".join(f"($${c}$$,$${t}$$)" for c,t in batch)
        sql = f"INSERT INTO codes(code,title) VALUES {values} ON CONFLICT (code) DO NOTHING"
        await db.exec(sql)
        added = len(batch)
    logger.info(f"ICD-10 load finished, attempted to insert {added} rows")
