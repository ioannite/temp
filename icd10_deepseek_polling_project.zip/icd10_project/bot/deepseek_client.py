import os
import httpx
from pydantic import BaseModel, field_validator
from loguru import logger
import orjson

DEEPSEEK_API_URL = os.getenv("DEEPSEEK_API_URL", "https://api.deepseek.com/v1/chat/completions")
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY")
DEEPSEEK_MODEL = os.getenv("DEEPSEEK_MODEL", "deepseek-chat")
TIMEOUT = 60

class CodeItem(BaseModel):
    code: str
    confidence: float
    @field_validator("code")
    @classmethod
    def upcase(cls, v: str) -> str:
        return (v or "").strip().upper()

class LLMResponse(BaseModel):
    codes: list[CodeItem] = []

def parse_json_safe(text: str) -> LLMResponse:
    try:
        data = orjson.loads(text)
        return LLMResponse.model_validate(data)
    except Exception as e:
        logger.warning(f"LLM JSON parse failed: {e}; raw={text!r}")
        return LLMResponse(codes=[])

async def ask_deepseek(system_prompt: str, user_prompt: str) -> LLMResponse:
    if not DEEPSEEK_API_KEY:
        logger.error("DEEPSEEK_API_KEY not set")
        return LLMResponse(codes=[])
    headers = {
        "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": DEEPSEEK_MODEL,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": 0.2,
        "top_p": 0.9,
        "response_format": {"type": "json_object"},
    }
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        resp = await client.post(DEEPSEEK_API_URL, headers=headers, json=payload)
        resp.raise_for_status()
        data = resp.json()
        content = data["choices"][0]["message"]["content"]
        return parse_json_safe(content)
