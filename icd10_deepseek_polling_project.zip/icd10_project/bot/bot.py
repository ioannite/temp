import os, asyncio
from aiogram import Bot, Dispatcher, F
from aiogram.types import Message
from aiogram.filters import CommandStart, Command
from loguru import logger
from dotenv import load_dotenv

from . import db
from .icd_loader import ensure_codes_loaded
from .deepseek_client import ask_deepseek
from .prompt_templates import SYSTEM_PROMPT, USER_PROMPT_TEMPLATE
from .utils import normalize_code, looks_like_code
from rapidfuzz import fuzz, process

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
CONFIDENCE_THRESHOLD = float(os.getenv("CONFIDENCE_THRESHOLD", "0.75"))

bot = Bot(BOT_TOKEN)
dp = Dispatcher()

async def search_codes_like(text: str, limit: int = 10):
    rows = await db.fetch("""
        SELECT code, title FROM codes
        WHERE title ILIKE '%' || $1 || '%'
        LIMIT 200
    """, text)
    candidates = [(r["title"], {"code": r["code"], "title": r["title"]}) for r in rows]
    if not candidates:
        rows2 = await db.fetch("""
            SELECT code, title FROM codes
            WHERE code ILIKE $1 || '%'
            LIMIT 50
        """, text.upper())
        return [{"code": r["code"], "title": r["title"], "score": 100} for r in rows2]

    ranked = process.extract(text, dict(candidates), scorer=fuzz.token_set_ratio, limit=limit)
    out = []
    for title, score, data in ranked:
        out.append({"code": data["code"], "title": data["title"], "score": score})
    return out

@dp.message(CommandStart())
async def on_start(m: Message):
    await m.answer("Привет! Отправьте клинические данные/диагноз — верну коды МКБ‑10.\n"
                   f"Текущий порог доверия: {CONFIDENCE_THRESHOLD:.2f}\n"
                   "Команды: /threshold 0.8 — установить порог, /help — помощь.")

@dp.message(Command("help"))
async def on_help(m: Message):
    await m.answer("""Отправьте текст: симптомы, диагноз, процедуры.
Я пришлю два блока:
• Надёжные (>= порога доверия)
• Предложения (< порога)

/threshold 0.75 — задать порог доверия (0..1)
""")

@dp.message(Command("threshold"))
async def on_threshold(m: Message):
    global CONFIDENCE_THRESHOLD
    parts = (m.text or "").split()
    if len(parts) != 2:
        return await m.answer(f"Сейчас порог: {CONFIDENCE_THRESHOLD:.2f}. Пример: /threshold 0.8")
    try:
        val = float(parts[1])
        if not (0 <= val <= 1):
            raise ValueError
        CONFIDENCE_THRESHOLD = val
        await m.answer(f"Ок, новый порог доверия: {CONFIDENCE_THRESHOLD:.2f}")
    except Exception:
        await m.answer("Дайте число 0..1. Пример: /threshold 0.7")

@dp.message(F.text.len() > 2)
async def on_query(m: Message):
    text = m.text.strip()
    await db.exec("INSERT INTO queries(user_id, text) VALUES($1,$2)", m.from_user.id, text)

    user_prompt = USER_PROMPT_TEMPLATE.format(text=text)
    llm = await ask_deepseek(SYSTEM_PROMPT, user_prompt)
    reliable, suggestions = [], []

    if llm.codes:
        codes = [normalize_code(c.code) for c in llm.codes]
        rows = await db.fetch("SELECT code,title FROM codes WHERE code = ANY($1)", codes)
        title_by_code = {r["code"].upper(): r["title"] for r in rows}
        for item in llm.codes:
            code = normalize_code(item.code)
            title = title_by_code.get(code, "")
            record = {"code": code, "title": title, "confidence": float(item.confidence)}
            if record["confidence"] >= CONFIDENCE_THRESHOLD and title:
                reliable.append(record)
            else:
                suggestions.append(record)

    if not reliable:
        top_db = await search_codes_like(text, limit=6)
        for r in top_db:
            suggestions.append({"code": r["code"], "title": r["title"], "confidence": None})

    row = await db.fetchrow("SELECT id FROM queries WHERE user_id=$1 ORDER BY id DESC LIMIT 1", m.from_user.id)
    qid = row["id"] if row else None
    if qid:
        for rec in reliable:
            await db.exec("INSERT INTO results(query_id, code, confidence, reliable) VALUES($1,$2,$3,true)",
                          qid, rec["code"], rec["confidence"])        
        for rec in suggestions:
            await db.exec("INSERT INTO results(query_id, code, confidence, reliable) VALUES($1,$2,$3,false)",
                          qid, rec.get("code"), rec.get("confidence"))

    def fmt_list(items):
        if not items:
            return "—"
        return "\n".join([f"• {it['code']} — {it['title']}" + (f" (p={it['confidence']:.2f})" if it.get('confidence') is not None else "") for it in items])

    text_resp = ""
    if reliable:
        text_resp += "\n<b>Надёжные</b> (>= порога):\n" + fmt_list(reliable)
    if suggestions:
        text_resp += "\n\n<b>Предложения</b>:\n" + fmt_list(suggestions)
    if not text_resp:
        text_resp = "Не нашёл кодов. Попробуйте переформулировать запрос."

    await m.answer(text_resp, parse_mode="HTML")


async def main():
    await db.get_pool()
    await ensure_codes_loaded()
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
